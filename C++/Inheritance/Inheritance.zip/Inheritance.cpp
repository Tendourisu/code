#include "Inheritance.hpp"
//Shape
Shape::Shape(double _x, double _y) : x(_x), y(_y) {}
Shape::Shape(const Shape &source) : x(source.x), y(source.y) {}
Shape& Shape::operator=(const Shape &source) {
    if (this == &source) return *this;
    x = source.x;
    y = source.y;
    return *this;
}
Shape::~Shape() {}
double Shape::GetArea() const { return 0; }
//Circle
Circle::Circle(double _x, double _y) : Shape(_x, _y) {
        if (_x < 0) x = 0;
}
Circle::Circle(const Circle &source) : Shape(source) {}
Circle& Circle::operator=(const Circle &source) {
    if (this == &source) return *this;
    Shape::operator=(source);
    return *this;
}
Circle::~Circle() {}
double Circle::GetArea() const {
    const double pi = 3.14159; 
    return pi * x * x;
}
double Circle::GetRadius() const { return x; }
void Circle::SetRadius(double r) {
    if (r >= 0) x = r;
}
//Rectangle
Rectangle::Rectangle(double _x, double _y) : Shape(_x, _y) {
    if (_x < 0) x = 0;
    if (_y < 0) y = 0;
}
Rectangle::Rectangle(const Rectangle &source) : Shape(source) {}
Rectangle& Rectangle::operator=(const Rectangle &source) {
    if (this == &source) return *this;
    Shape::operator=(source);
    return *this;
}
Rectangle::~Rectangle() {}
double Rectangle::GetArea() const {
    return x * y;
}
double Rectangle::GetLength() const { return x; }
double Rectangle::GetWidth() const { return y; }
void Rectangle::SetLength(double length) {
    if (length >= 0) x = length;
}
void Rectangle::SetWidth(double width) {
    if (width >= 0) y = width;
}
//Square
Square::Square(double _x, double _y) : Rectangle(_x, _y) {
    if (_x < 0) x = 0;
    if (_y < 0) y = 0;
}
Square::Square(const Square &source) : Rectangle(source) {}
Square& Square::operator=(const Square &source) {
    if (this == &source) return *this;
    Rectangle::operator=(source);
    return *this;
}
Square::~Square() {}
double Square::GetArea() const {
    return x * x;
}
double Square::GetSide() const { return x; }
void Square::SetSide(double side) {
    if (side >= 0) x = side;
}